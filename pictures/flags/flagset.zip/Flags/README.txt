Flags
=====

Designer: Nordic Factory (http://www.nordicfactory.com)
License: Free for commercial use (Include link to authors website)
